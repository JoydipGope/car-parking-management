
  # Car_Parking_Slot_Booking_System

  This is a code bundle for Car_Parking_Slot_Booking_System. The original project is available at https://www.figma.com/design/zog2sXy88d3KCHmGy6TPjp/Car_Parking_Slot_Booking_System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  